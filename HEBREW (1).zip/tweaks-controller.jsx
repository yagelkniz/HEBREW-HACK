/* global React, ReactDOM, TweaksPanel, TweakSection, TweakRadio, TweakSlider, useTweaks */

const TWEAK_DEFAULTS = /*EDITMODE-BEGIN*/{
  "vibe": "sunset",
  "playfulness": 80,
  "voice": "display"
}/*EDITMODE-END*/;

function TweaksController() {
  const [t, setTweak] = useTweaks(TWEAK_DEFAULTS);

  React.useEffect(() => {
    const html = document.documentElement;
    html.setAttribute('data-vibe',  t.vibe);
    html.setAttribute('data-voice', t.voice);
    const play = Math.max(0, Math.min(100, t.playfulness)) / 100;
    html.style.setProperty('--tw-play', String(play));
    html.setAttribute('data-play', play === 0 ? '0' : 'on');
  }, [t.vibe, t.voice, t.playfulness]);

  return (
    <TweaksPanel title="Tweaks">
      <TweakSection label="Vibe" />
      <TweakRadio
        label="Palette"
        value={t.vibe}
        options={['sunset', 'ocean', 'forest']}
        onChange={(v) => setTweak('vibe', v)} />

      <TweakSection label="Energy" />
      <TweakSlider
        label="Playfulness"
        value={t.playfulness}
        min={0} max={100} step={1} unit="%"
        onChange={(v) => setTweak('playfulness', v)} />

      <TweakSection label="Headline voice" />
      <TweakRadio
        label="Style"
        value={t.voice}
        options={['display', 'scribble', 'stencil']}
        onChange={(v) => setTweak('voice', v)} />
    </TweaksPanel>
  );
}

// Mount on a separate root so we don't disturb the main app
(function mountTweaks() {
  const node = document.createElement('div');
  node.id = 'tweaks-root';
  document.body.appendChild(node);
  ReactDOM.createRoot(node).render(<TweaksController />);
})();
